#include "hal_timer2.h"
#include "usart.h"
#include "public.h"

uint8_t F_UseUsartN=0; //ϵͳĿǰʹ�õĴ��ڱ�ǣ�0-ʹ��USART1; 1-ʹ��USART2;

//================================================================
void set_mem(uint8_t *buf, uint8_t len,uint8_t val)
{
    while(len--)
    {
        *buf=val;
        buf++;   
    }  
}

uint8_t lrc_chk(uint8_t *buf, uint8_t len)
{
    uint8_t   chk=0;
    while(len--)
    {
        chk -= *buf;
        buf++;   
    }  
	return chk;  
}

/*************************/
#define	HEAD 0xFE
uint8_t rev_datapage(uint8_t *buf, uint8_t *len)
{
	uint8_t i;
	
	/*if(F_UART4_RX_FINISH != 0)
	{
		F_UART4_RX_FINISH=0;
		F_UseUsartN=1;
		
		for(i=0; i<UART4_RX_COUNT; i++)
		{
			buf[i]=UART4_RX_BUF[i];
		}

		if((buf[0] != HEAD))// �ҵ�ͷ
		{UART4_RX_COUNT=0;return	0;}//�������ݲ���ȷ

		if(buf[1]>(MAXUBUF-4) || buf[1]<3 )
		{UART4_RX_COUNT=0;return	0;}
		
		*len=UART4_RX_COUNT;// �յ����� 
		UART4_RX_COUNT=0;
		
		if(*len != (buf[1]+2))			
		{return	0;}
		
#ifdef NOCHK
		return 1;
#endif
		if( buf[buf[1]+1] == lrc_chk(buf+1,buf[1]) )
		{return	1;}

		return	0;
	}
	else*/ if(F_USART1_RX_FINISH != 0)
	{
		F_USART1_RX_FINISH=0;
		F_UseUsartN=0;

		for(i=0; i<USART1_RX_COUNT; i++)
		{
			buf[i]=USART1_RX_BUF[i];
		}

		if((buf[0] != HEAD))// �ҵ�ͷ
		{USART1_RX_COUNT=0;return	0;}//�������ݲ���ȷ

		if(buf[1]>(MAXUBUF-4) || buf[1]<3 )
		{USART1_RX_COUNT=0;return	0;}
		
		*len=USART1_RX_COUNT;// �յ����� 
		USART1_RX_COUNT=0;
		
		if(*len != (buf[1]+2))			
		{return	0;}
		
#ifdef NOCHK
		return 1;
#endif
		if( buf[buf[1]+1] == lrc_chk(buf+1,buf[1]) )
		{return	1;}

		return	0;
	}
	else
	{return	0;}//����δ�������
}

void send_datapag(uint8_t *buf)
{
	buf[0]=HEAD;
	buf[buf[1]+1] = lrc_chk(buf+1,buf[1]);
	uartsend(buf,buf[1]+2);	
}

void uartsend(uint8_t *buf, uint8_t len)
{
	while(len--)
	{
		
			USART1_SendData((uint16_t)(*buf));
		
		buf++;
	}
}

