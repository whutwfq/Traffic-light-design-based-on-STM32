
#include <string.h>
#include "stm32f10x_flash.h"
 #include "flash.h"
// addr:��ַ  count:������
flash_status_t FlashErase(uint32_t addr, uint8_t count)
{
  uint8_t i;
 
  FLASH_Unlock();
 
  FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
 
  for(i = 0; i < count; ++i)
  {
    if(FLASH_ErasePage(addr + i * FLASH_SECTOR_SIZE) != FLASH_COMPLETE)
    {
      return FLASH_FAILURE;
    }
  }
 
  FLASH_Lock();
 
  return FLASH_SUCCESS;
}
 
uint32_t FlashWrite(uint32_t addr, uint8_t *buffer, uint32_t length)
{
  uint16_t i, data = 0;
 
  FLASH_Unlock();
 
  FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
 
  for(i = 0; i < length; i += 2)
  {
    data = (*(buffer + i + 1) << 8) + (*(buffer + i));
    if(FLASH_ProgramHalfWord((uint32_t)(addr + i), data) != FLASH_COMPLETE)
    {
      return i;
    }
  }
  
  FLASH_Lock();
 
  return length;
}
 
uint32_t FlashRead(uint32_t addr, uint8_t *buffer, uint32_t length)
{
  memcpy(buffer, (void *)addr, length);
 
  return length;
}
