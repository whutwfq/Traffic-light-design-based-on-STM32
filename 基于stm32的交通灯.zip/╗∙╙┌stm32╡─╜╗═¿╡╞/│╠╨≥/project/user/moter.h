#ifndef __MOTER_H__
#define __MOTER_H__
void MoterGo(void);
void MoterRunLines(unsigned int i);
void MoterInit(void);



#endif
