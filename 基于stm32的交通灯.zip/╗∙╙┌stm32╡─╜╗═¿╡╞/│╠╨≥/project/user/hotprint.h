#ifndef __HOTPRINT_H__
#define __HOTPRINT_H__

//sbit lock=P1^0;
//sbit clk=P1^1;
//sbit MOSI=P1^2;

//sbit HP_EN=P1^3;
//sbit noPeaperCheck=P1^4;
//sbit key=P1^5;


void HP_init(void);
void SendByte(unsigned char a);
void SendData(unsigned char *p);
char hotprintf(unsigned char *dat);
void hotprintfname(unsigned char *datas);
void hotprintfline(unsigned char *datas);



#endif
