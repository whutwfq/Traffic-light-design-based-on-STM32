#ifndef __BIGIOT_H__
#define __BIGIOT_H__

//#define ID "7606"
//#define password "f7f951ac2"
#define targetID "7605"
void checkin(void);
void checkout(void);
void ask(unsigned char busy);
void BMP_OK(void);


#endif
