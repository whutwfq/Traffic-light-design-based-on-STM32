#include "stm32f103_config.h"

//#define A  0x02
//#define nA 0x01
//#define B  0x08
//#define nB 0x04
unsigned char  M_Out[]={ A|nB, nB, nA|nB, nA, nA|B, B, A|B, A};

unsigned int moter_times,temp;

void MoterInit(void)
{
	STM32_GPIOx_Init(moto_port00_Init);
	STM32_GPIOx_Init(moto_port01_Init);
	STM32_GPIOx_Init(moto_port02_Init);
	STM32_GPIOx_Init(moto_port03_Init);
}
void MoterGo(void)
{
	temp=temp&0xf0;
	temp=temp|M_Out[moter_times];
	moto_port00=temp&0x01;
	moto_port01=temp>>1&0x01;
	moto_port02=temp>>2&0x01;
	moto_port03=temp>>3&0x01;
	delay_us(1800);
	moter_times++;
	if(moter_times>=8)moter_times=0;
}

void MoterRunLines(unsigned int i)
{
	unsigned int  j;
	for(j=0;j<i;j++)
	{
		MoterGo();
	}
}
