#include "stm32f103_config.h"
#include "submodule.h"


unsigned char longs[6];

void HP_init()
{
//	P0=0x00;
	DST00=0;
	DST01=0;
	DST02=0;
	DST03=0;
	DST04=0;
	DST05=0;
	HP_EN=1;
	HP_EN=0;
	clk=0;
	lock=0;
	delay_ms(200);
}

void SendByte(unsigned char a)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		clk=0;
		MOSI=a&0x01;
		delay_us(5);
		clk=1;
		a>>=1;
	}
}

void SendData(unsigned char *p)
{
	uchar i;
	
	lock=0;
	for(i=0;i<48;i++)
	{
		SendByte(*p);
		p++;
	}
	lock=1;
	
}

void SendDataLite(unsigned char *p,unsigned char a)
{
	uchar i;
	
	lock=0;
	for(i=0;i<48;i++)
	{
		if(a==0)SendByte((*p)&0xaa);
		else SendByte((*p)&0x55);
		
		p++;
	}
	lock=1;
	
}

void checklong(unsigned char *p)
{
	uchar i,j,k,m;
	for(i=0;i<6;i++)
	{
		for(j=0;j<8;j++)
		{
			uchar a=(*p);
			for(k=0;k<8;k++)
			{
				if(((a>>k)&0x01)==1)m++;
			}
			p++;
		}
		longs[i]=m;
		m=0;
		
	}	
}





char hotprintf(unsigned char *dat)
{
	unsigned char *p=dat;
	unsigned int j,i,s,temp,k;
	unsigned char  huancun[48][16];
	unsigned char  hc[48];
	unsigned char hcm[32];
	unsigned long addr;
	if(noPeaperCheck==0)return 0;
	
		

//	while(*(p+1)!=0)
	while(*p!=0)
	{
	
		s=0;
		for(i=0;i<48;i++)
		{
			for(j=0;j<16;j++)
			huancun[i][j]=0;
		}
		
		while(*p)
		{
			if(*p==' ')
			{
				p++;
				s++;
			}
			else if(*p=='\r'||*p=='\n')
			{
				p++;
				s++;
				break;
			}
			else if(*p & 0x80)
			{
				addr=(((*p<<8)+(*(p+1)))-0x8140)*32;
				sFLASH_ReadBuffer(hcm,addr,32);
				for(i=0;i<2;i++)
				{
					for(j=0;j<16;j++)
					{
						huancun[s+i][j]=hcm[j*2+i];
					}
				}
				p+=2;
				s+=2;
			}
			else
			{
				for(i=0;i<255;i++)
				{
					if(*p==asc[i])
					{
						for(j=0;j<16;j++)
						huancun[s][j]=ascm[i][j];
						break;
					}
				}
				p++;
				s++;	
			}
			if(s>46)break;
		}
		
		
		HP_EN=1;
		for(i=0;i<16;i++)
		{
			for(j=0;j<48;j++)
			{	
				hc[j]=huancun[j][i];	
			}
			SendData(hc);
			for(k=0;k<4;k++)
			{
				for(j=0;j<6;j++)
				{
					temp=1;
					temp=temp<<j;
				//	P0=temp;
					
					DST00=temp&0x01;
					DST01=temp>>1&0x01;
					DST02=temp>>2&0x01;
					DST03=temp>>3&0x01;
					DST04=temp>>4&0x01;
					DST05=temp>>5&0x01;
					
					delay_us(5000);
					//P0=0x00;
					DST00=0;
					DST01=0;
					DST02=0;
					DST03=0;
					DST04=0;
					DST05=0;
				}

				MoterRunLines(1);	
			}
			
			
		}
		
		MoterRunLines(8);
		HP_EN=0;
		//P0=0x00;
		DST00=0;
		DST01=0;
		DST02=0;
		DST03=0;
		DST04=0;
		DST05=0;
		
	}
	return 1;
}

void hotprintfline(unsigned char *datas)
{
	//12*64
	
	unsigned char j;
	unsigned char temp;
	unsigned char k;
	unsigned char m;
	unsigned char hcs[48]={
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	
	for(m=0;m<38;m++)hcs[m]=datas[m];
	
//	SendData(hcs);
//	checklong(hcs);
	SendData(hcs);
	for(k=0;k<4;k++)
	{
		
		for(j=0;j<6;j++)
		{
			temp=1;
			temp=temp<<j;
			
			DST00=temp&0x01;
			DST01=temp>>1&0x01;
			DST02=temp>>2&0x01;
			DST03=temp>>3&0x01;
			DST04=temp>>4&0x01;
			DST05=temp>>5&0x01;
			
			delay_ms(8);
			DST00=0;
			DST01=0;
			DST02=0;
			DST03=0;
			DST04=0;
			DST05=0;
		}
		
		MoterRunLines(1);	
	}
}

void hotprintfname(unsigned char *datas)
{
	//12*64
	
	unsigned char j;
	unsigned char temp;
	unsigned char k;
	unsigned char m;
	unsigned char hcs[48]={
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	HP_EN=1;
	for(m=0;m<64;m++)
	{
		
		hcs[0]=datas[m*12+0];
		hcs[1]=datas[m*12+1];
		hcs[2]=datas[m*12+2];
		hcs[3]=datas[m*12+3];
		hcs[4]=datas[m*12+4];
		hcs[5]=datas[m*12+5];
		hcs[6]=datas[m*12+6];
		hcs[7]=datas[m*12+7];
		hcs[8]=datas[m*12+8];
		hcs[9]=datas[m*12+9];
		hcs[10]=datas[m*12+10];
		hcs[11]=datas[m*12+11];
		SendData(hcs);
		
		for(k=0;k<4;k++)
		{
			for(j=0;j<6;j++)
			{
				temp=1;
				temp=temp<<j;
			//	P0=temp;
				
				DST00=temp&0x01;
				DST01=temp>>1&0x01;
				DST02=temp>>2&0x01;
				DST03=temp>>3&0x01;
				DST04=temp>>4&0x01;
				DST05=temp>>5&0x01;
				
				delay_us(5000);
				//P0=0x00;
				DST00=0;
				DST01=0;
				DST02=0;
				DST03=0;
				DST04=0;
				DST05=0;
			}

			MoterRunLines(1);	
		}
	}


	MoterRunLines(8);
	HP_EN=0;
	//P0=0x00;
	DST00=0;
	DST01=0;
	DST02=0;
	DST03=0;
	DST04=0;
	DST05=0;
}

