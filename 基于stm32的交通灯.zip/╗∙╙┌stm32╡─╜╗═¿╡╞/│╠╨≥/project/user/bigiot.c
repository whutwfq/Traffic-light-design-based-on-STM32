#include "stm32f103_config.h"
unsigned char id[4];
unsigned char password[9];

void checkin(void)
{
	USART2_SendStr("{\"M\":\"checkin\",\"ID\":\"");
	USART2_SendStr(id);
	USART2_SendStr("\",\"K\":\"");
	USART2_SendStr(password);
	USART2_SendStr("\"}\n");
}

void checkout(void)
{
	USART2_SendStr("{\"M\":\"checkout\",\"ID\":\"");
	USART2_SendStr(id);
	USART2_SendStr("\",\"K\":\"");
	USART2_SendStr(password);
	USART2_SendStr("\"}\n");
}

void ask(unsigned char busy)
{
	USART2_SendStr("{\"M\":\"say\",\"ID\":\"D");
	USART2_SendStr(targetID);
	USART2_SendStr("\",\"C\":\"C\",\"SIGN\":\"");
	if(busy==1)	USART2_SendStr("Busy");
	else		USART2_SendStr("Unbusy");
	USART2_SendStr("\"}\n");
}

void BMP_OK(void)
{
	USART2_SendStr("{\"M\":\"say\",\"ID\":\"D");
	USART2_SendStr(targetID);
	USART2_SendStr("\",\"C\":\"C\",\"SIGN\":\"");
	USART2_SendStr("finishDraw");
	USART2_SendStr("\"}\n");
}
	

